# Products-DB
React.js frontend with Node.js and MySQL backend - full stack sample database app
